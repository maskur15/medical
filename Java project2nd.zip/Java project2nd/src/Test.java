/**
 * Created by ASUS on 07-Mar-20.
 */
public class Test {
    public static void main(String args[])
    {
        String from="sabilhasan2018@gmail.com";
        String pass="sormi00000";
        String to ="mnhruhan@gmail.com";
        String sub="! MASKUR";
        String mess="FRom MBSTU?";
        Mailer.send(from,pass,to,sub,mess);
    }
}
